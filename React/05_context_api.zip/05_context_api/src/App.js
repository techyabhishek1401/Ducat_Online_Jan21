import logo from './logo.svg';
import './App.css';
import Image from './Image';
function App() {
  return (
    <div className="App">
      <Image />
    </div>
  );
}

export default App;
